import React from 'react';
import '../component styles/home.css';

const Home = () => {
  return (
    <div className="home-container">
      Welcome to the TODO App!
    </div>
  );
};

export default Home;
